import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { projectsAPI } from '../utils/api';
import {
  Building2, Search, ArrowLeft, Filter, X, MapPin,
  IndianRupee, Home, Tag, CheckCircle, Loader2,
  ChevronDown, Eye, EyeOff, Download, Video, FileText,
  Image as ImageIcon, Shield, User, LogOut, ExternalLink, Edit, Trash2
} from 'lucide-react';

const SearchPage = () => {
  const navigate = useNavigate();
  const { user, logout, isAdmin } = useAuth();
  
  const [filters, setFilters] = useState({
    project_name: '',
    developer_name: '',
    location: '',
    budget_min: '',
    budget_max: '',
    configurations: '',
    availability_status: '',
    client_tags: ''
  });
  
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [showFilters, setShowFilters] = useState(true);
  const [selectedProject, setSelectedProject] = useState(null);
  const [pagination, setPagination] = useState({ page: 1, pages: 1, total: 0 });
  const [editMode, setEditMode] = useState(false);
  const [editedProject, setEditedProject] = useState(null);
  const [saving, setSaving] = useState(false);
  const [selectedProjects, setSelectedProjects] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [exporting, setExporting] = useState(false);

  const configOptions = ['1 BHK', '2 BHK', '3 BHK', '4 BHK', '5 BHK', '6 BHK', 'Penthouse', 'Villa'];
  const statusOptions = ['Available', 'Sold Out', 'Limited Inventory', 'Coming Soon'];

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleSearch = async (page = 1) => {
    setLoading(true);
    setSearched(true);
    
    try {
      const searchFilters = { ...filters, page, limit: 10 };
      // Remove empty filters
      Object.keys(searchFilters).forEach(key => {
        if (!searchFilters[key]) delete searchFilters[key];
      });
      
      const data = await projectsAPI.search(searchFilters);
      setResults(data.projects);
      setPagination(data.pagination);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const clearFilters = () => {
    setFilters({
      project_name: '',
      developer_name: '',
      location: '',
      budget_min: '',
      budget_max: '',
      configurations: '',
      availability_status: '',
      client_tags: ''
    });
  };

  const toggleProjectVisibility = async (projectId, currentVisibility) => {
    try {
      await projectsAPI.toggleProjectVisibility(projectId, !currentVisibility);
      handleSearch(pagination.page);
    } catch (error) {
      console.error('Toggle visibility error:', error);
    }
  };

  const toggleFieldVisibility = async (projectId, field, currentVisibility) => {
    try {
      await projectsAPI.updateVisibility(projectId, field, !currentVisibility);
      handleSearch(pagination.page);
    } catch (error) {
      console.error('Toggle field visibility error:', error);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const handleEdit = () => {
    setEditMode(true);
    setEditedProject({...selectedProject});
  };

  const handleCancelEdit = () => {
    setEditMode(false);
    setEditedProject(null);
  };

  const handleEditChange = (field, value) => {
    setEditedProject(prev => ({...prev, [field]: value}));
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      await projectsAPI.update(editedProject.id, editedProject);
      setSelectedProject(editedProject);
      setEditMode(false);
      handleSearch(pagination.page); // Refresh the list
    } catch (error) {
      console.error('Save error:', error);
      alert('Failed to save changes');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Are you sure you want to delete this project?')) return;
    try {
      await projectsAPI.delete(selectedProject.id);
      setSelectedProject(null);
      handleSearch(pagination.page); // Refresh the list
    } catch (error) {
      console.error('Delete error:', error);
      alert('Failed to delete project');
    }
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setSelectedProjects([]);
      setSelectAll(false);
    } else {
      setSelectedProjects(results.map(p => p.id));
      setSelectAll(true);
    }
  };

  const handleSelectProject = (projectId) => {
    setSelectedProjects(prev => {
      if (prev.includes(projectId)) {
        const newSelection = prev.filter(id => id !== projectId);
        if (newSelection.length === 0) setSelectAll(false);
        return newSelection;
      } else {
        const newSelection = [...prev, projectId];
        if (newSelection.length === results.length) setSelectAll(true);
        return newSelection;
      }
    });
  };

  const handleExportSelected = async () => {
    if (selectedProjects.length === 0) {
      alert('Please select at least one project to export');
      return;
    }
    try {
      setExporting(true);
      const blob = await projectsAPI.exportProjects(selectedProjects);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `projects_export_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export projects');
    } finally {
      setExporting(false);
    }
  };

  const handleExportAll = async () => {
    try {
      setExporting(true);
      const blob = await projectsAPI.exportProjects([]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `all_projects_export_${new Date().toISOString().split('T')[0]}.xlsx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
      alert('Failed to export all projects');
    } finally {
      setExporting(false);
    }
  };

  const handleDownloadTemplate = async () => {
    try {
      const blob = await projectsAPI.downloadTemplate();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'project_template.xlsx';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Download template error:', error);
      alert('Failed to download template');
    }
  };

  const formatBudget = (amount) => {
    if (!amount) return 'N/A';
    if (amount >= 10000000) return `₹${(amount / 10000000).toFixed(2)} Cr`;
    if (amount >= 100000) return `₹${(amount / 100000).toFixed(2)} Lac`;
    return `₹${amount.toLocaleString()}`;
  };

  return (
    <div className="search-page">
      <div className="page-bg">
        <div className="gradient-orb orb-1"></div>
        <div className="gradient-orb orb-2"></div>
      </div>

      <nav className="page-nav">
        <div className="nav-left">
          <Link to="/dashboard" className="back-btn">
            <ArrowLeft size={20} />
          </Link>
          <Link to="/" className="nav-logo">
            <Building2 size={24} strokeWidth={1.5} />
            <span>MAK Realty</span>
          </Link>
        </div>
        <div className="nav-right">
          <div className="user-badge">
            {isAdmin() ? <Shield size={16} /> : <User size={16} />}
            <span>{user?.name}</span>
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            <LogOut size={18} />
          </button>
        </div>
      </nav>

      <main className="search-content">
        <div className="search-header">
          <h1>
            <Search size={28} />
            <span>Search Projects</span>
          </h1>
          <p>Find projects matching your client requirements</p>
        </div>

        <div className="search-layout">
          {/* Filters Panel */}
          <aside className={`filters-panel ${showFilters ? 'open' : ''}`}>
            <div className="filters-header">
              <h2>
                <Filter size={18} />
                <span>Filters</span>
              </h2>
              <button className="clear-btn" onClick={clearFilters}>
                <X size={16} />
                <span>Clear</span>
              </button>
            </div>

            <div className="filters-body">
              <div className="filter-group">
                <label>Project Name</label>
                <input
                  type="text"
                  name="project_name"
                  value={filters.project_name}
                  onChange={handleFilterChange}
                  placeholder="Search by name..."
                />
              </div>

              <div className="filter-group">
                <label>Developer</label>
                <input
                  type="text"
                  name="developer_name"
                  value={filters.developer_name}
                  onChange={handleFilterChange}
                  placeholder="Developer name..."
                />
              </div>

              <div className="filter-group">
                <label>
                  <MapPin size={14} />
                  Location
                </label>
                <input
                  type="text"
                  name="location"
                  value={filters.location}
                  onChange={handleFilterChange}
                  placeholder="City or micro-market..."
                />
              </div>

              <div className="filter-group">
                <label>
                  <IndianRupee size={14} />
                  Budget Range
                </label>
                <div className="range-inputs">
                  <input
                    type="number"
                    name="budget_min"
                    value={filters.budget_min}
                    onChange={handleFilterChange}
                    placeholder="Min"
                  />
                  <span>to</span>
                  <input
                    type="number"
                    name="budget_max"
                    value={filters.budget_max}
                    onChange={handleFilterChange}
                    placeholder="Max"
                  />
                </div>
              </div>

              <div className="filter-group">
                <label>
                  <Home size={14} />
                  Configuration
                </label>
                <select
                  name="configurations"
                  value={filters.configurations}
                  onChange={handleFilterChange}
                >
                  <option value="">All Configurations</option>
                  {configOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label>
                  <CheckCircle size={14} />
                  Availability
                </label>
                <select
                  name="availability_status"
                  value={filters.availability_status}
                  onChange={handleFilterChange}
                >
                  <option value="">All Status</option>
                  {statusOptions.map(opt => (
                    <option key={opt} value={opt}>{opt}</option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label>
                  <Tag size={14} />
                  Client Tags
                </label>
                <input
                  type="text"
                  name="client_tags"
                  value={filters.client_tags}
                  onChange={handleFilterChange}
                  placeholder="Tags (comma separated)"
                />
              </div>
            </div>

            <div className="filters-footer">
              <button className="search-btn" onClick={() => handleSearch(1)}>
                {loading ? <Loader2 className="spin" size={18} /> : <Search size={18} />}
                <span>Search</span>
              </button>
            </div>
          </aside>

          {/* Results Panel */}
          <div className="results-panel">
            <div className="results-header">
              <button
                className="toggle-filters-btn"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter size={18} />
                <span>{showFilters ? 'Hide' : 'Show'} Filters</span>
              </button>

              {searched && (
                <span className="results-count">
                  {pagination.total} project{pagination.total !== 1 ? 's' : ''} found
                </span>
              )}
            </div>

            {searched && results.length > 0 && (
              <div className="bulk-actions-bar">
                <div className="select-all-section">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={selectAll}
                      onChange={handleSelectAll}
                    />
                    <span>Select All ({results.length})</span>
                  </label>
                  {selectedProjects.length > 0 && (
                    <span className="selected-count">
                      {selectedProjects.length} selected
                    </span>
                  )}
                </div>
                <div className="export-buttons">
                  <button
                    className="template-btn"
                    onClick={handleDownloadTemplate}
                  >
                    <Download size={16} />
                    <span>Template</span>
                  </button>
                  <button
                    className="export-btn"
                    onClick={handleExportSelected}
                    disabled={selectedProjects.length === 0 || exporting}
                  >
                    <Download size={16} />
                    <span>{exporting ? 'Exporting...' : 'Export Selected'}</span>
                  </button>
                  <button
                    className="export-all-btn"
                    onClick={handleExportAll}
                    disabled={exporting}
                  >
                    <Download size={16} />
                    <span>{exporting ? 'Exporting...' : 'Export All'}</span>
                  </button>
                </div>
              </div>
            )}

            <div className="results-grid">
              {loading ? (
                <div className="loading-state">
                  <Loader2 className="spin" size={32} />
                  <p>Searching projects...</p>
                </div>
              ) : !searched ? (
                <div className="empty-state">
                  <Search size={48} />
                  <h3>Start Your Search</h3>
                  <p>Use the filters to find projects matching your requirements</p>
                </div>
              ) : results.length === 0 ? (
                <div className="empty-state">
                  <Building2 size={48} />
                  <h3>No Projects Found</h3>
                  <p>Try adjusting your filters for better results</p>
                </div>
              ) : (
                results.map(project => (
                  <div
                    key={project.id}
                    className={`project-card ${!project.is_visible && isAdmin() ? 'hidden-card' : ''} ${selectedProjects.includes(project.id) ? 'selected' : ''}`}
                  >
                    <label className="project-checkbox">
                      <input
                        type="checkbox"
                        checked={selectedProjects.includes(project.id)}
                        onChange={() => handleSelectProject(project.id)}
                      />
                    </label>

                    {isAdmin() && (
                      <button
                        className="visibility-toggle main-toggle"
                        onClick={() => toggleProjectVisibility(project.id, project.is_visible)}
                        title={project.is_visible ? 'Hide from users' : 'Show to users'}
                      >
                        {project.is_visible ? <Eye size={16} /> : <EyeOff size={16} />}
                      </button>
                    )}

                    <div className="card-header">
                      <h3>{project.project_name}</h3>
                      {project.developer_name && (
                        <span className="developer">by {project.developer_name}</span>
                      )}
                    </div>

                    <div className="card-body">
                      <div className="card-row">
                        <MapPin size={14} />
                        <span>{project.location || project.micro_market || 'N/A'}</span>
                        {isAdmin() && (
                          <button 
                            className="field-toggle"
                            onClick={() => toggleFieldVisibility(
                              project.id, 
                              'location', 
                              project.visibility_settings?.location !== false
                            )}
                          >
                            {project.visibility_settings?.location !== false 
                              ? <Eye size={12} /> 
                              : <EyeOff size={12} />
                            }
                          </button>
                        )}
                      </div>

                      <div className="card-row">
                        <IndianRupee size={14} />
                        <span>
                          {formatBudget(project.budget_min)} - {formatBudget(project.budget_max)}
                        </span>
                        {isAdmin() && (
                          <button 
                            className="field-toggle"
                            onClick={() => toggleFieldVisibility(
                              project.id, 
                              'budget', 
                              project.visibility_settings?.budget !== false
                            )}
                          >
                            {project.visibility_settings?.budget !== false 
                              ? <Eye size={12} /> 
                              : <EyeOff size={12} />
                            }
                          </button>
                        )}
                      </div>

                      <div className="card-row">
                        <Home size={14} />
                        <span>
                          {project.configurations?.length > 0 
                            ? project.configurations.join(', ') 
                            : 'N/A'
                          }
                        </span>
                        {isAdmin() && (
                          <button 
                            className="field-toggle"
                            onClick={() => toggleFieldVisibility(
                              project.id, 
                              'configurations', 
                              project.visibility_settings?.configurations !== false
                            )}
                          >
                            {project.visibility_settings?.configurations !== false 
                              ? <Eye size={12} /> 
                              : <EyeOff size={12} />
                            }
                          </button>
                        )}
                      </div>

                      <div className="status-badge" data-status={project.availability_status}>
                        {project.availability_status || 'Available'}
                      </div>
                    </div>

                    <div className="card-footer">
                      <button 
                        className="view-btn"
                        onClick={() => setSelectedProject(project)}
                      >
                        View Details
                      </button>
                      
                      <div className="download-btns">
                        {project.media?.some(m => m?.media_type === 'floor_plan') && (
                          <a
                            href={projectsAPI.getMediaDownloadUrl(
                              project.media.find(m => m?.media_type === 'floor_plan')?.id
                            )}
                            className="download-btn"
                            title="Download Floor Plan"
                          >
                            <FileText size={16} />
                          </a>
                        )}
                        {project.media?.some(m => m?.media_type === 'video') && (
                          <a
                            href={projectsAPI.getMediaDownloadUrl(
                              project.media.find(m => m?.media_type === 'video')?.id
                            )}
                            className="download-btn"
                            title="Download Video"
                          >
                            <Video size={16} />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {pagination.pages > 1 && (
              <div className="pagination">
                {Array.from({ length: pagination.pages }, (_, i) => (
                  <button
                    key={i + 1}
                    className={pagination.page === i + 1 ? 'active' : ''}
                    onClick={() => handleSearch(i + 1)}
                  >
                    {i + 1}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Project Detail Modal */}
      {selectedProject && (
        <div className="modal-overlay" onClick={() => setSelectedProject(null)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelectedProject(null)}>
              <X size={24} />
            </button>
            
            <div className="modal-header">
              <h2>{editMode ? 'Edit Project' : selectedProject.project_name}</h2>
              {!editMode && selectedProject.developer_name && (
                <span className="developer">by {selectedProject.developer_name}</span>
              )}
              {!editMode && (
                <div className="modal-actions">
                  <button className="edit-btn" onClick={handleEdit}>
                    <Edit size={16} />
                    <span>Edit</span>
                  </button>
                  {isAdmin() && (
                    <button className="delete-btn" onClick={handleDelete}>
                      <Trash2 size={16} />
                      <span>Delete</span>
                    </button>
                  )}
                </div>
              )}
              {editMode && (
                <div className="modal-actions">
                  <button className="cancel-btn" onClick={handleCancelEdit}>Cancel</button>
                  <button className="save-btn" onClick={handleSave} disabled={saving}>
                    {saving ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>
              )}
            </div>

            <div className="modal-body">
              {!editMode ? (
                <>
                  <div className="detail-grid">
                    <div className="detail-item">
                      <label><MapPin size={16} /> Location</label>
                      <span>{selectedProject.location || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <label><MapPin size={16} /> Micro Market</label>
                      <span>{selectedProject.micro_market || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <label><IndianRupee size={16} /> Budget Min</label>
                      <span>{formatBudget(selectedProject.budget_min)}</span>
                    </div>
                    <div className="detail-item">
                      <label><IndianRupee size={16} /> Budget Max</label>
                      <span>{formatBudget(selectedProject.budget_max)}</span>
                    </div>
                    <div className="detail-item">
                      <label><Home size={16} /> Configurations</label>
                      <span>{selectedProject.configurations?.join(', ') || 'N/A'}</span>
                    </div>
                    <div className="detail-item">
                      <label><CheckCircle size={16} /> Status</label>
                      <span>{selectedProject.availability_status || 'Available'}</span>
                    </div>
                    {selectedProject.inventory_notes && (
                      <div className="detail-item full-width">
                        <label>Inventory Notes</label>
                        <span>{selectedProject.inventory_notes}</span>
                      </div>
                    )}
                    {selectedProject.google_maps_link && (
                      <div className="detail-item full-width">
                        <label><MapPin size={16} /> Google Maps</label>
                        <a
                          href={selectedProject.google_maps_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="maps-link"
                        >
                          <span>View on Google Maps</span>
                          <ExternalLink size={14} />
                        </a>
                      </div>
                    )}
                  </div>

                  {selectedProject.description && (
                    <div className="description-section">
                      <h3>Description</h3>
                      <p>{selectedProject.description}</p>
                    </div>
                  )}

                  {/* Additional Attributes Section - View Mode */}
                  {(() => {
                    const visibleAttributes = user?.visible_attributes || {};
                    const attributesToShow = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
                      .filter(num => visibleAttributes[num] !== false);

                    if (attributesToShow.length === 0) return null;

                    return (
                      <div className="attributes-section">
                        <h3>
                          Additional Details
                          {isAdmin() && <span className="admin-badge">(Admin Only)</span>}
                        </h3>
                        <div className="attributes-grid">
                          {attributesToShow.map(num => {
                            const attrValue = selectedProject[`attribute_${num}`];
                            return (
                              <div key={num} className="attribute-item">
                                <label>Attribute {num}</label>
                                <span>{attrValue || 'Not set'}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })()}
                </>
              ) : (
                <div className="edit-form">
                  <div className="form-group">
                    <label>Project Name *</label>
                    <input
                      type="text"
                      value={editedProject?.project_name || ''}
                      onChange={(e) => handleEditChange('project_name', e.target.value)}
                    />
                  </div>
                  <div className="form-group">
                    <label>Developer Name</label>
                    <input
                      type="text"
                      value={editedProject?.developer_name || ''}
                      onChange={(e) => handleEditChange('developer_name', e.target.value)}
                    />
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Location</label>
                      <input
                        type="text"
                        value={editedProject?.location || ''}
                        onChange={(e) => handleEditChange('location', e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label>Micro Market</label>
                      <input
                        type="text"
                        value={editedProject?.micro_market || ''}
                        onChange={(e) => handleEditChange('micro_market', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Budget Min</label>
                      <input
                        type="number"
                        value={editedProject?.budget_min || ''}
                        onChange={(e) => handleEditChange('budget_min', e.target.value)}
                      />
                    </div>
                    <div className="form-group">
                      <label>Budget Max</label>
                      <input
                        type="number"
                        value={editedProject?.budget_max || ''}
                        onChange={(e) => handleEditChange('budget_max', e.target.value)}
                      />
                    </div>
                  </div>
                  <div className="form-group">
                    <label>Google Maps Link</label>
                    <input
                      type="url"
                      value={editedProject?.google_maps_link || ''}
                      onChange={(e) => handleEditChange('google_maps_link', e.target.value)}
                      placeholder="https://maps.google.com/..."
                    />
                  </div>
                  <div className="form-group">
                    <label>Description</label>
                    <textarea
                      value={editedProject?.description || ''}
                      onChange={(e) => handleEditChange('description', e.target.value)}
                      rows="3"
                    />
                  </div>
                  <div className="form-group">
                    <label>Inventory Notes</label>
                    <textarea
                      value={editedProject?.inventory_notes || ''}
                      onChange={(e) => handleEditChange('inventory_notes', e.target.value)}
                      rows="2"
                    />
                  </div>

                  {isAdmin() && (
                    <div className="attributes-edit-section">
                      <h3>Additional Attributes (Admin Only)</h3>
                      <div className="attributes-edit-grid">
                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20].map(num => (
                          <div key={num} className="form-group">
                            <label>Attribute {num}</label>
                            <input
                              type="text"
                              value={editedProject?.[`attribute_${num}`] || ''}
                              onChange={(e) => handleEditChange(`attribute_${num}`, e.target.value)}
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {selectedProject.client_requirement_tags?.length > 0 && (
                <div className="tags-section">
                  <h3>Client Tags</h3>
                  <div className="tags">
                    {selectedProject.client_requirement_tags.map((tag, i) => (
                      <span key={i} className="tag">{tag}</span>
                    ))}
                  </div>
                </div>
              )}

              {selectedProject.media?.length > 0 && (
                <div className="media-section">
                  <h3>Downloads</h3>
                  <div className="media-list">
                    {selectedProject.media.filter(m => m?.id).map(media => (
                      <a
                        key={media.id}
                        href={projectsAPI.getMediaDownloadUrl(media.id)}
                        className="media-item"
                      >
                        {media.media_type === 'floor_plan' && <FileText size={20} />}
                        {media.media_type === 'video' && <Video size={20} />}
                        {media.media_type === 'image' && <ImageIcon size={20} />}
                        {media.media_type === 'brochure' && <FileText size={20} />}
                        {media.media_type === 'pdf' && <FileText size={20} />}
                        <div className="media-info">
                          <span className="media-name">{media.file_name}</span>
                          {media.configuration && (
                            <span className="media-config">{media.configuration}</span>
                          )}
                        </div>
                        <Download size={16} />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <style>{`
        .search-page {
          min-height: 100vh;
          background: #0a0a0f;
          position: relative;
        }

        .page-bg {
          position: fixed;
          inset: 0;
          pointer-events: none;
          overflow: hidden;
        }

        .gradient-orb {
          position: absolute;
          border-radius: 50%;
          filter: blur(100px);
          opacity: 0.2;
        }

        .orb-1 {
          width: 500px;
          height: 500px;
          background: linear-gradient(135deg, #2d4a3e 0%, #1a2f25 100%);
          top: -100px;
          right: -100px;
        }

        .orb-2 {
          width: 400px;
          height: 400px;
          background: linear-gradient(135deg, #c9a962 0%, #8b7355 100%);
          bottom: -100px;
          left: -100px;
        }

        .page-nav {
          position: sticky;
          top: 0;
          z-index: 100;
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 1rem 2rem;
          background: rgba(10, 10, 15, 0.9);
          border-bottom: 1px solid rgba(255, 255, 255, 0.06);
          backdrop-filter: blur(10px);
        }

        .nav-left {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .back-btn {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          color: rgba(255, 255, 255, 0.7);
          transition: all 0.2s ease;
        }

        .back-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #fff;
        }

        .nav-logo {
          display: flex;
          align-items: center;
          gap: 0.75rem;
          color: #c9a962;
          text-decoration: none;
          font-family: 'Outfit', sans-serif;
          font-weight: 600;
        }

        .nav-right {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .user-badge {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          background: rgba(255, 255, 255, 0.05);
          border-radius: 20px;
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .user-badge svg {
          color: #c9a962;
        }

        .logout-btn {
          width: 40px;
          height: 40px;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          display: flex;
          align-items: center;
          justify-content: center;
          color: rgba(255, 255, 255, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .logout-btn:hover {
          background: rgba(220, 38, 38, 0.1);
          border-color: rgba(220, 38, 38, 0.3);
          color: #fca5a5;
        }

        .search-content {
          position: relative;
          z-index: 10;
          padding: 2rem;
        }

        .search-header {
          text-align: center;
          margin-bottom: 2rem;
        }

        .search-header h1 {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.75rem;
          font-family: 'Cormorant Garamond', serif;
          font-size: 2rem;
          color: #fff;
          margin-bottom: 0.5rem;
        }

        .search-header h1 svg {
          color: #2d4a3e;
        }

        .search-header p {
          font-family: 'Outfit', sans-serif;
          color: rgba(255, 255, 255, 0.5);
        }

        .search-layout {
          display: flex;
          gap: 2rem;
          max-width: 1400px;
          margin: 0 auto;
        }

        .filters-panel {
          width: 300px;
          flex-shrink: 0;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 16px;
          overflow: hidden;
          height: fit-content;
          position: sticky;
          top: 100px;
        }

        .filters-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 1rem 1.25rem;
          border-bottom: 1px solid rgba(255, 255, 255, 0.08);
        }

        .filters-header h2 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 1rem;
          font-weight: 600;
          color: #fff;
        }

        .clear-btn {
          display: flex;
          align-items: center;
          gap: 0.25rem;
          background: none;
          border: none;
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          color: rgba(255, 255, 255, 0.5);
          cursor: pointer;
          transition: color 0.2s ease;
        }

        .clear-btn:hover {
          color: #fca5a5;
        }

        .filters-body {
          padding: 1.25rem;
          display: flex;
          flex-direction: column;
          gap: 1.25rem;
        }

        .filter-group {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .filter-group label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          color: rgba(255, 255, 255, 0.6);
        }

        .filter-group input,
        .filter-group select {
          width: 100%;
          padding: 0.75rem 1rem;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #fff;
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          transition: all 0.2s ease;
        }

        .filter-group input::placeholder {
          color: rgba(255, 255, 255, 0.3);
        }

        .filter-group input:focus,
        .filter-group select:focus {
          outline: none;
          border-color: rgba(45, 74, 62, 0.5);
        }

        .filter-group select {
          cursor: pointer;
          appearance: none;
          background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='rgba(255,255,255,0.5)' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");
          background-repeat: no-repeat;
          background-position: right 0.75rem center;
        }

        .range-inputs {
          display: flex;
          align-items: center;
          gap: 0.5rem;
        }

        .range-inputs input {
          flex: 1;
        }

        .range-inputs span {
          color: rgba(255, 255, 255, 0.4);
          font-size: 0.85rem;
        }

        .filters-footer {
          padding: 1.25rem;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .search-btn {
          width: 100%;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 0.5rem;
          padding: 0.875rem;
          background: linear-gradient(135deg, #3d5a4c 0%, #2d4a3e 100%);
          border: none;
          border-radius: 10px;
          color: #fff;
          font-family: 'Outfit', sans-serif;
          font-size: 0.95rem;
          font-weight: 500;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .search-btn:hover {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(45, 74, 62, 0.3);
        }

        .spin {
          animation: spin 1s linear infinite;
        }

        @keyframes spin {
          to { transform: rotate(360deg); }
        }

        .results-panel {
          flex: 1;
          min-width: 0;
        }

        .results-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1.5rem;
        }

        .toggle-filters-btn {
          display: none;
          align-items: center;
          gap: 0.5rem;
          padding: 0.75rem 1rem;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: rgba(255, 255, 255, 0.7);
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          cursor: pointer;
        }

        .results-count {
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.5);
        }

        .results-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(320px, 1fr));
          gap: 1.5rem;
        }

        .loading-state,
        .empty-state {
          grid-column: 1 / -1;
          display: flex;
          flex-direction: column;
          align-items: center;
          justify-content: center;
          padding: 4rem 2rem;
          text-align: center;
        }

        .loading-state svg,
        .empty-state svg {
          color: rgba(255, 255, 255, 0.2);
          margin-bottom: 1rem;
        }

        .loading-state p,
        .empty-state h3 {
          font-family: 'Outfit', sans-serif;
          color: rgba(255, 255, 255, 0.6);
        }

        .empty-state p {
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.4);
          margin-top: 0.5rem;
        }

        .project-card {
          position: relative;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 16px;
          padding: 1.5rem;
          transition: all 0.3s ease;
        }

        .project-card:hover {
          background: rgba(255, 255, 255, 0.05);
          border-color: rgba(255, 255, 255, 0.12);
        }

        .project-card.hidden-card {
          opacity: 0.6;
          border-style: dashed;
        }

        .project-card.selected {
          border-color: rgba(45, 74, 62, 0.6);
          background: rgba(45, 74, 62, 0.1);
        }

        .project-checkbox {
          position: absolute;
          top: 1rem;
          left: 1rem;
          cursor: pointer;
        }

        .project-checkbox input[type="checkbox"] {
          width: 18px;
          height: 18px;
          cursor: pointer;
          accent-color: #2d4a3e;
        }

        .bulk-actions-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 1.5rem;
          padding: 1rem 1.25rem;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 12px;
        }

        .select-all-section {
          display: flex;
          align-items: center;
          gap: 1rem;
        }

        .checkbox-label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.8);
          cursor: pointer;
        }

        .checkbox-label input[type="checkbox"] {
          width: 18px;
          height: 18px;
          cursor: pointer;
          accent-color: #2d4a3e;
        }

        .selected-count {
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          color: #4ade80;
          padding: 0.25rem 0.75rem;
          background: rgba(45, 74, 62, 0.2);
          border-radius: 12px;
        }

        .export-buttons {
          display: flex;
          gap: 0.75rem;
        }

        .template-btn,
        .export-btn,
        .export-all-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border-radius: 8px;
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          cursor: pointer;
          transition: all 0.2s ease;
          border: 1px solid;
        }

        .template-btn {
          background: rgba(59, 130, 246, 0.1);
          border-color: rgba(59, 130, 246, 0.3);
          color: #60a5fa;
        }

        .template-btn:hover {
          background: rgba(59, 130, 246, 0.2);
        }

        .export-btn {
          background: rgba(201, 169, 98, 0.1);
          border-color: rgba(201, 169, 98, 0.3);
          color: #c9a962;
        }

        .export-btn:hover:not(:disabled) {
          background: rgba(201, 169, 98, 0.2);
        }

        .export-btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
        }

        .export-all-btn {
          background: linear-gradient(135deg, #3d5a4c 0%, #2d4a3e 100%);
          border-color: rgba(45, 74, 62, 0.5);
          color: #fff;
        }

        .export-all-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(45, 74, 62, 0.3);
        }

        .export-all-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .visibility-toggle {
          position: absolute;
          top: 1rem;
          right: 1rem;
          width: 32px;
          height: 32px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(201, 169, 98, 0.1);
          border: 1px solid rgba(201, 169, 98, 0.3);
          border-radius: 8px;
          color: #c9a962;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .visibility-toggle:hover {
          background: rgba(201, 169, 98, 0.2);
        }

        .card-header {
          margin-bottom: 1rem;
          padding-right: 3rem;
          padding-left: 2.5rem;
        }

        .card-header h3 {
          font-family: 'Outfit', sans-serif;
          font-size: 1.1rem;
          font-weight: 600;
          color: #fff;
          margin-bottom: 0.25rem;
        }

        .card-header .developer {
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          color: rgba(255, 255, 255, 0.5);
        }

        .card-body {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .card-row {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.7);
        }

        .card-row svg:first-child {
          color: rgba(255, 255, 255, 0.4);
          flex-shrink: 0;
        }

        .card-row span {
          flex: 1;
        }

        .field-toggle {
          width: 24px;
          height: 24px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 4px;
          color: rgba(255, 255, 255, 0.4);
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .field-toggle:hover {
          background: rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.7);
        }

        .status-badge {
          display: inline-block;
          padding: 0.35rem 0.75rem;
          border-radius: 20px;
          font-family: 'Outfit', sans-serif;
          font-size: 0.75rem;
          font-weight: 500;
          margin-top: 0.5rem;
          width: fit-content;
        }

        .status-badge[data-status="Available"] {
          background: rgba(34, 197, 94, 0.1);
          color: #4ade80;
        }

        .status-badge[data-status="Sold Out"] {
          background: rgba(239, 68, 68, 0.1);
          color: #f87171;
        }

        .status-badge[data-status="Limited Inventory"] {
          background: rgba(251, 191, 36, 0.1);
          color: #fbbf24;
        }

        .status-badge[data-status="Coming Soon"] {
          background: rgba(59, 130, 246, 0.1);
          color: #60a5fa;
        }

        .card-footer {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-top: 1.25rem;
          padding-top: 1rem;
          border-top: 1px solid rgba(255, 255, 255, 0.08);
        }

        .view-btn {
          padding: 0.5rem 1rem;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: rgba(255, 255, 255, 0.7);
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .view-btn:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #fff;
        }

        .download-btns {
          display: flex;
          gap: 0.5rem;
        }

        .download-btn {
          width: 36px;
          height: 36px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(45, 74, 62, 0.2);
          border: 1px solid rgba(45, 74, 62, 0.4);
          border-radius: 8px;
          color: #4ade80;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .download-btn:hover {
          background: rgba(45, 74, 62, 0.4);
        }

        .pagination {
          display: flex;
          justify-content: center;
          gap: 0.5rem;
          margin-top: 2rem;
        }

        .pagination button {
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: rgba(255, 255, 255, 0.6);
          font-family: 'Outfit', sans-serif;
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .pagination button:hover,
        .pagination button.active {
          background: rgba(45, 74, 62, 0.3);
          border-color: rgba(45, 74, 62, 0.5);
          color: #fff;
        }

        /* Modal Styles */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.8);
          backdrop-filter: blur(8px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 1000;
          padding: 2rem;
        }

        .modal-content {
          position: relative;
          width: 100%;
          max-width: 700px;
          max-height: 90vh;
          overflow-y: auto;
          background: #141419;
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 20px;
          padding: 2rem;
        }

        .modal-close {
          position: absolute;
          top: 1.5rem;
          right: 1.5rem;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 10px;
          color: rgba(255, 255, 255, 0.6);
          cursor: pointer;
          transition: all 0.2s ease;
        }

        .modal-close:hover {
          background: rgba(255, 255, 255, 0.1);
          color: #fff;
        }

        .modal-header {
          margin-bottom: 1.5rem;
          padding-right: 3rem;
        }

        .modal-header h2 {
          font-family: 'Cormorant Garamond', serif;
          font-size: 1.75rem;
          color: #fff;
          margin-bottom: 0.25rem;
        }

        .modal-header .developer {
          font-family: 'Outfit', sans-serif;
          font-size: 0.95rem;
          color: rgba(255, 255, 255, 0.5);
        }

        .modal-actions {
          display: flex;
          gap: 0.75rem;
          margin-top: 1rem;
        }

        .edit-btn, .delete-btn, .save-btn, .cancel-btn {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          padding: 0.5rem 1rem;
          border-radius: 8px;
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          cursor: pointer;
          transition: all 0.2s ease;
          border: 1px solid;
        }

        .edit-btn {
          background: rgba(59, 130, 246, 0.1);
          border-color: rgba(59, 130, 246, 0.3);
          color: #60a5fa;
        }

        .edit-btn:hover {
          background: rgba(59, 130, 246, 0.2);
        }

        .delete-btn {
          background: rgba(239, 68, 68, 0.1);
          border-color: rgba(239, 68, 68, 0.3);
          color: #f87171;
        }

        .delete-btn:hover {
          background: rgba(239, 68, 68, 0.2);
        }

        .save-btn {
          background: linear-gradient(135deg, #3d5a4c 0%, #2d4a3e 100%);
          border-color: rgba(45, 74, 62, 0.5);
          color: #fff;
        }

        .save-btn:hover:not(:disabled) {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(45, 74, 62, 0.3);
        }

        .save-btn:disabled {
          opacity: 0.6;
          cursor: not-allowed;
        }

        .cancel-btn {
          background: rgba(255, 255, 255, 0.05);
          border-color: rgba(255, 255, 255, 0.1);
          color: rgba(255, 255, 255, 0.7);
        }

        .cancel-btn:hover {
          background: rgba(255, 255, 255, 0.1);
        }

        .edit-form {
          display: flex;
          flex-direction: column;
          gap: 1rem;
        }

        .form-group {
          display: flex;
          flex-direction: column;
          gap: 0.5rem;
        }

        .form-group label {
          font-family: 'Outfit', sans-serif;
          font-size: 0.85rem;
          color: rgba(255, 255, 255, 0.6);
        }

        .form-group input,
        .form-group textarea {
          width: 100%;
          padding: 0.75rem;
          background: rgba(255, 255, 255, 0.05);
          border: 1px solid rgba(255, 255, 255, 0.1);
          border-radius: 8px;
          color: #fff;
          font-family: 'Outfit', sans-serif;
          font-size: 0.95rem;
        }

        .form-group input:focus,
        .form-group textarea:focus {
          outline: none;
          border-color: rgba(45, 74, 62, 0.5);
        }

        .form-row {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
        }

        .attributes-edit-section {
          margin-top: 1.5rem;
          padding-top: 1.5rem;
          border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        .attributes-edit-section h3 {
          font-family: 'Outfit', sans-serif;
          font-size: 1rem;
          font-weight: 600;
          color: #c9a962;
          margin-bottom: 1rem;
        }

        .attributes-edit-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 0.75rem;
        }

        .detail-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 1rem;
          margin-bottom: 1.5rem;
        }

        .detail-item {
          background: rgba(255, 255, 255, 0.03);
          border-radius: 10px;
          padding: 1rem;
        }

        .detail-item.full-width {
          grid-column: 1 / -1;
        }

        .detail-item label {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 0.8rem;
          color: rgba(255, 255, 255, 0.5);
          margin-bottom: 0.5rem;
        }

        .detail-item span {
          font-family: 'Outfit', sans-serif;
          font-size: 0.95rem;
          color: #fff;
        }

        .description-section,
        .tags-section,
        .media-section {
          margin-bottom: 1.5rem;
        }

        .description-section h3,
        .tags-section h3,
        .media-section h3 {
          font-family: 'Outfit', sans-serif;
          font-size: 1rem;
          font-weight: 600;
          color: #fff;
          margin-bottom: 0.75rem;
        }

        .description-section p {
          font-family: 'Outfit', sans-serif;
          font-size: 0.95rem;
          color: rgba(255, 255, 255, 0.7);
          line-height: 1.6;
        }

        .tags {
          display: flex;
          flex-wrap: wrap;
          gap: 0.5rem;
        }

        .tag {
          padding: 0.35rem 0.75rem;
          background: rgba(201, 169, 98, 0.1);
          border: 1px solid rgba(201, 169, 98, 0.3);
          border-radius: 20px;
          font-family: 'Outfit', sans-serif;
          font-size: 0.8rem;
          color: #c9a962;
        }

        .media-list {
          display: flex;
          flex-direction: column;
          gap: 0.75rem;
        }

        .media-item {
          display: flex;
          align-items: center;
          gap: 1rem;
          padding: 1rem;
          background: rgba(255, 255, 255, 0.03);
          border: 1px solid rgba(255, 255, 255, 0.08);
          border-radius: 10px;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .media-item:hover {
          background: rgba(255, 255, 255, 0.06);
          border-color: rgba(45, 74, 62, 0.4);
        }

        .media-item svg:first-child {
          color: rgba(255, 255, 255, 0.5);
        }

        .media-info {
          flex: 1;
          display: flex;
          flex-direction: column;
        }

        .media-name {
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: #fff;
        }

        .media-config {
          font-family: 'Outfit', sans-serif;
          font-size: 0.75rem;
          color: rgba(255, 255, 255, 0.5);
        }

        .media-item svg:last-child {
          color: #4ade80;
        }

        .maps-link {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          color: #4ade80;
          text-decoration: none;
          transition: all 0.2s ease;
        }

        .maps-link:hover {
          color: #22c55e;
          text-decoration: underline;
        }

        .attributes-section {
          margin-bottom: 1.5rem;
        }

        .attributes-section h3 {
          display: flex;
          align-items: center;
          gap: 0.5rem;
          font-family: 'Outfit', sans-serif;
          font-size: 1rem;
          font-weight: 600;
          color: #fff;
          margin-bottom: 1rem;
        }

        .admin-badge {
          font-size: 0.7rem;
          font-weight: 400;
          padding: 0.25rem 0.5rem;
          background: rgba(201, 169, 98, 0.1);
          border: 1px solid rgba(201, 169, 98, 0.3);
          border-radius: 12px;
          color: #c9a962;
        }

        .attributes-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 0.75rem;
        }

        .attribute-item {
          background: rgba(255, 255, 255, 0.03);
          border-radius: 8px;
          padding: 0.75rem;
        }

        .attribute-item label {
          display: block;
          font-family: 'Outfit', sans-serif;
          font-size: 0.75rem;
          color: rgba(255, 255, 255, 0.5);
          margin-bottom: 0.35rem;
        }

        .attribute-item span {
          font-family: 'Outfit', sans-serif;
          font-size: 0.9rem;
          color: rgba(255, 255, 255, 0.9);
        }

        @media (max-width: 1024px) {
          .filters-panel {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            width: 320px;
            border-radius: 0;
            z-index: 200;
            transform: translateX(-100%);
            transition: transform 0.3s ease;
          }

          .filters-panel.open {
            transform: translateX(0);
          }

          .toggle-filters-btn {
            display: flex;
          }
        }

        @media (max-width: 640px) {
          .search-content {
            padding: 1rem;
          }

          .results-grid {
            grid-template-columns: 1fr;
          }

          .detail-grid {
            grid-template-columns: 1fr;
          }

          .attributes-grid {
            grid-template-columns: 1fr;
          }

          .modal-content {
            padding: 1.5rem;
          }

          .bulk-actions-bar {
            flex-direction: column;
            gap: 1rem;
            align-items: stretch;
          }

          .export-buttons {
            flex-wrap: wrap;
          }

          .template-btn,
          .export-btn,
          .export-all-btn {
            flex: 1;
            min-width: 120px;
          }
        }
      `}</style>
    </div>
  );
};

export default SearchPage;
