const express = require('express');
const { pool } = require('../config/database');
const { authenticateToken, requireAdmin } = require('../middleware/auth');

const router = express.Router();

// Get all users (admin only)
router.get('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(
      `SELECT id, email, name, role, two_factor_enabled, is_visible, visible_attributes, created_at, updated_at
       FROM users
       ORDER BY created_at DESC`
    );

    res.json({ users: result.rows });
  } catch (error) {
    console.error('Fetch users error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle user visibility (admin only)
router.patch('/:userId/visibility', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { visible } = req.body;

    const result = await pool.query(
      `UPDATE users SET is_visible = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, email, name, role, is_visible`,
      [visible, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: `User ${visible ? 'unhidden' : 'hidden'} successfully`,
      user: result.rows[0]
    });
  } catch (error) {
    console.error('Toggle user visibility error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update user role (admin only)
router.patch('/:userId/role', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { role } = req.body;

    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: 'Invalid role' });
    }

    // Prevent self-demotion
    if (parseInt(userId) === req.user.id && role === 'user') {
      return res.status(400).json({ error: 'Cannot change your own role' });
    }

    const result = await pool.query(
      `UPDATE users SET role = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, email, name, role`,
      [role, userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'User role updated successfully',
      user: result.rows[0]
    });
  } catch (error) {
    console.error('Update user role error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update user attribute visibility (admin only)
router.patch('/:userId/attributes', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { visibleAttributes } = req.body;

    if (!visibleAttributes || typeof visibleAttributes !== 'object') {
      return res.status(400).json({ error: 'Invalid visibleAttributes format' });
    }

    const result = await pool.query(
      `UPDATE users SET visible_attributes = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2
       RETURNING id, email, name, visible_attributes`,
      [JSON.stringify(visibleAttributes), userId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({
      message: 'User attribute visibility updated successfully',
      user: result.rows[0]
    });
  } catch (error) {
    console.error('Update attribute visibility error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
