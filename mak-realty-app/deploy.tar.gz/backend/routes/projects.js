const express = require('express');
const { body, query, validationResult } = require('express-validator');
const multer = require('multer');
const xlsx = require('xlsx');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../config/database');
const { authenticateToken, requireAdmin, optionalAuth } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueName = `${uuidv4()}-${file.originalname}`;
    cb(null, uniqueName);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 100 * 1024 * 1024 }, // 100MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = [
      'application/pdf',
      'image/jpeg',
      'image/png',
      'image/gif',
      'video/mp4',
      'video/webm',
      'video/quicktime',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'application/vnd.ms-excel'
    ];
    if (allowedTypes.includes(file.mimetype) || file.originalname.endsWith('.xlsx')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'), false);
    }
  }
});

// Search and filter projects
router.get('/search', optionalAuth, async (req, res) => {
  try {
    const {
      project_name,
      developer_name,
      location,
      budget_min,
      budget_max,
      configurations,
      availability_status,
      client_tags,
      page = 1,
      limit = 10
    } = req.query;

    const isAdmin = req.user?.role === 'admin';
    let queryParams = [];
    let conditions = [];
    let paramCount = 0;

    // Only show visible projects for non-admin users
    if (!isAdmin) {
      conditions.push('p.is_visible = true');
    }

    if (project_name) {
      paramCount++;
      conditions.push(`p.project_name ILIKE $${paramCount}`);
      queryParams.push(`%${project_name}%`);
    }

    if (developer_name) {
      paramCount++;
      conditions.push(`p.developer_name ILIKE $${paramCount}`);
      queryParams.push(`%${developer_name}%`);
    }

    if (location) {
      paramCount++;
      conditions.push(`(p.location ILIKE $${paramCount} OR p.micro_market ILIKE $${paramCount})`);
      queryParams.push(`%${location}%`);
    }

    if (budget_min) {
      paramCount++;
      conditions.push(`p.budget_max >= $${paramCount}`);
      queryParams.push(parseFloat(budget_min));
    }

    if (budget_max) {
      paramCount++;
      conditions.push(`p.budget_min <= $${paramCount}`);
      queryParams.push(parseFloat(budget_max));
    }

    if (configurations) {
      const configArray = configurations.split(',');
      paramCount++;
      conditions.push(`p.configurations && $${paramCount}`);
      queryParams.push(configArray);
    }

    if (availability_status) {
      paramCount++;
      conditions.push(`p.availability_status = $${paramCount}`);
      queryParams.push(availability_status);
    }

    if (client_tags) {
      const tagsArray = client_tags.split(',');
      paramCount++;
      conditions.push(`p.client_requirement_tags && $${paramCount}`);
      queryParams.push(tagsArray);
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (parseInt(page) - 1) * parseInt(limit);

    // Get total count
    const countQuery = `SELECT COUNT(*) FROM projects p ${whereClause}`;
    const countResult = await pool.query(countQuery, queryParams);
    const totalCount = parseInt(countResult.rows[0].count);

    // Get projects with pagination
    paramCount++;
    const limitParam = paramCount;
    paramCount++;
    const offsetParam = paramCount;

    const projectsQuery = `
      SELECT p.*,
             json_agg(DISTINCT jsonb_build_object(
               'id', pm.id,
               'media_type', pm.media_type,
               'file_name', pm.file_name,
               'file_path', pm.file_path,
               'configuration', pm.configuration,
               'is_visible', pm.is_visible
             )) FILTER (WHERE pm.id IS NOT NULL) as media
      FROM projects p
      LEFT JOIN project_media pm ON p.id = pm.project_id ${!isAdmin ? 'AND pm.is_visible = true' : ''}
      ${whereClause}
      GROUP BY p.id
      ORDER BY p.created_at DESC
      LIMIT $${limitParam} OFFSET $${offsetParam}
    `;

    queryParams.push(parseInt(limit), offset);
    const projectsResult = await pool.query(projectsQuery, queryParams);

    // Filter visibility settings for non-admin users
    const projects = projectsResult.rows.map(project => {
      if (!isAdmin && project.visibility_settings) {
        const visibilitySettings = project.visibility_settings;
        Object.keys(visibilitySettings).forEach(key => {
          if (!visibilitySettings[key]) {
            project[key] = null;
          }
        });
      }
      return project;
    });

    res.json({
      projects,
      pagination: {
        total: totalCount,
        page: parseInt(page),
        limit: parseInt(limit),
        pages: Math.ceil(totalCount / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({ error: 'Server error during search' });
  }
});

// Export projects to Excel
router.post('/export', authenticateToken, async (req, res) => {
  try {
    const { projectIds } = req.body;
    const isAdmin = req.user.role === 'admin';

    let query;
    let params;

    if (projectIds && projectIds.length > 0) {
      query = `SELECT * FROM projects WHERE id = ANY($1)`;
      params = [projectIds];
    } else {
      query = `SELECT * FROM projects ${!isAdmin ? 'WHERE is_visible = true' : ''} ORDER BY created_at DESC`;
      params = [];
    }

    const result = await pool.query(query, params);
    const projects = result.rows;

    const workbook = xlsx.utils.book_new();

    const excelData = projects.map(p => ({
      'Project Name': p.project_name,
      'Developer Name': p.developer_name,
      'Location': p.location,
      'Micro Market': p.micro_market,
      'Budget Min': p.budget_min,
      'Budget Max': p.budget_max,
      'Configurations': p.configurations?.join(', '),
      'Description': p.description,
      'Availability Status': p.availability_status,
      'Inventory Notes': p.inventory_notes,
      'Client Tags': p.client_requirement_tags?.join(', '),
      'Google Maps Link': p.google_maps_link
    }));

    const worksheet = xlsx.utils.json_to_sheet(excelData);
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Projects');

    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=projects-export-${Date.now()}.xlsx`);
    res.send(buffer);
  } catch (error) {
    console.error('Export error:', error);
    res.status(500).json({ error: 'Server error during export' });
  }
});

// Download Excel template
router.get('/template/download', authenticateToken, (req, res) => {
  try {
    const workbook = xlsx.utils.book_new();

    const templateData = [{
      'Project Name': 'Sample Project',
      'Developer Name': 'Sample Developer',
      'Location': 'Mumbai',
      'Micro Market': 'Andheri West',
      'Budget Min': '5000000',
      'Budget Max': '7500000',
      'Configurations': '2 BHK, 3 BHK',
      'Description': 'Luxury residential project',
      'Availability Status': 'Available',
      'Inventory Notes': 'Limited units available',
      'Client Tags': 'Luxury, Prime Location',
      'Google Maps Link': 'https://maps.google.com/...'
    }];

    const worksheet = xlsx.utils.json_to_sheet(templateData);
    xlsx.utils.book_append_sheet(workbook, worksheet, 'Projects');

    const buffer = xlsx.write(workbook, { type: 'buffer', bookType: 'xlsx' });

    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename=projects-template.xlsx');
    res.send(buffer);
  } catch (error) {
    console.error('Template download error:', error);
    res.status(500).json({ error: 'Server error during template download' });
  }
});

// Get single project
router.get('/:id', optionalAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const isAdmin = req.user?.role === 'admin';

    const projectQuery = `
      SELECT p.*, 
             json_agg(DISTINCT jsonb_build_object(
               'id', pm.id,
               'media_type', pm.media_type,
               'file_name', pm.file_name,
               'file_path', pm.file_path,
               'configuration', pm.configuration,
               'description', pm.description,
               'is_visible', pm.is_visible
             )) FILTER (WHERE pm.id IS NOT NULL) as media
      FROM projects p
      LEFT JOIN project_media pm ON p.id = pm.project_id ${!isAdmin ? 'AND pm.is_visible = true' : ''}
      WHERE p.id = $1 ${!isAdmin ? 'AND p.is_visible = true' : ''}
      GROUP BY p.id
    `;

    const result = await pool.query(projectQuery, [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({ project: result.rows[0] });
  } catch (error) {
    console.error('Get project error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create project (manual upload)
router.post('/', authenticateToken, [
  body('project_name').notEmpty().trim(),
  body('budget_min').optional().isFloat({ min: 0 }),
  body('budget_max').optional().isFloat({ min: 0 }),
  body('configurations').optional().isArray()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const {
      project_name,
      developer_name,
      location,
      micro_market,
      budget_min,
      budget_max,
      configurations,
      description,
      availability_status,
      inventory_notes,
      client_requirement_tags,
      google_maps_link,
      attribute_1, attribute_2, attribute_3, attribute_4, attribute_5,
      attribute_6, attribute_7, attribute_8, attribute_9, attribute_10,
      attribute_11, attribute_12, attribute_13, attribute_14, attribute_15,
      attribute_16, attribute_17, attribute_18, attribute_19, attribute_20
    } = req.body;

    const result = await pool.query(
      `INSERT INTO projects (
        project_name, developer_name, location, micro_market,
        budget_min, budget_max, configurations, description,
        availability_status, inventory_notes, client_requirement_tags,
        google_maps_link,
        attribute_1, attribute_2, attribute_3, attribute_4, attribute_5,
        attribute_6, attribute_7, attribute_8, attribute_9, attribute_10,
        attribute_11, attribute_12, attribute_13, attribute_14, attribute_15,
        attribute_16, attribute_17, attribute_18, attribute_19, attribute_20,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20, $21, $22, $23, $24, $25, $26, $27, $28, $29, $30, $31, $32, $33)
      RETURNING *`,
      [
        project_name, developer_name, location, micro_market,
        budget_min, budget_max, configurations || [], description,
        availability_status || 'Available', inventory_notes,
        client_requirement_tags || [], google_maps_link,
        attribute_1, attribute_2, attribute_3, attribute_4, attribute_5,
        attribute_6, attribute_7, attribute_8, attribute_9, attribute_10,
        attribute_11, attribute_12, attribute_13, attribute_14, attribute_15,
        attribute_16, attribute_17, attribute_18, attribute_19, attribute_20,
        req.user.id
      ]
    );

    // Log activity
    await pool.query(
      `INSERT INTO activity_logs (user_id, action, entity_type, entity_id, details)
       VALUES ($1, $2, $3, $4, $5)`,
      [req.user.id, 'create', 'project', result.rows[0].id, { project_name }]
    );

    res.status(201).json({
      message: 'Project created successfully',
      project: result.rows[0]
    });
  } catch (error) {
    console.error('Create project error:', error);
    res.status(500).json({ error: 'Server error during project creation' });
  }
});

// Bulk upload via Excel
router.post('/bulk-upload', authenticateToken, upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const workbook = xlsx.readFile(req.file.path);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(worksheet);

    const results = {
      success: 0,
      failed: 0,
      errors: []
    };

    for (const row of data) {
      try {
        // Map Excel columns to database fields (attributes excluded - admin only)
        const project = {
          project_name: row['Project Name'] || row.project_name,
          developer_name: row['Developer Name'] || row.developer_name,
          location: row['Location'] || row.location,
          micro_market: row['Micro Market'] || row.micro_market,
          budget_min: parseFloat(row['Budget Min'] || row.budget_min) || null,
          budget_max: parseFloat(row['Budget Max'] || row.budget_max) || null,
          configurations: (row['Configurations'] || row.configurations)?.split(',').map(c => c.trim()) || [],
          description: row['Description'] || row.description,
          availability_status: row['Availability Status'] || row.availability_status || 'Available',
          inventory_notes: row['Inventory Notes'] || row.inventory_notes,
          client_requirement_tags: (row['Client Tags'] || row.client_requirement_tags)?.split(',').map(t => t.trim()) || [],
          google_maps_link: row['Google Maps Link'] || row.google_maps_link
        };

        if (!project.project_name) {
          results.failed++;
          results.errors.push({ row: results.success + results.failed, error: 'Project name is required' });
          continue;
        }

        await pool.query(
          `INSERT INTO projects (
            project_name, developer_name, location, micro_market,
            budget_min, budget_max, configurations, description,
            availability_status, inventory_notes, client_requirement_tags,
            google_maps_link,
            created_by
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
          [
            project.project_name, project.developer_name, project.location,
            project.micro_market, project.budget_min, project.budget_max,
            project.configurations, project.description, project.availability_status,
            project.inventory_notes, project.client_requirement_tags, project.google_maps_link,
            req.user.id
          ]
        );

        results.success++;
      } catch (err) {
        results.failed++;
        results.errors.push({ row: results.success + results.failed, error: err.message });
      }
    }

    // Clean up uploaded file
    fs.unlinkSync(req.file.path);

    console.log('Bulk upload results:', JSON.stringify(results, null, 2));

    res.json({
      message: 'Bulk upload completed',
      results
    });
  } catch (error) {
    console.error('Bulk upload error:', error);
    console.error('Error details:', error.message);
    console.error('Stack:', error.stack);
    res.status(500).json({
      error: 'Server error during bulk upload',
      details: error.message
    });
  }
});

// Upload media files for a project
router.post('/:id/media', authenticateToken, upload.array('files', 10), async (req, res) => {
  try {
    const { id } = req.params;
    const { media_type, configuration, description } = req.body;

    // Verify project exists
    const projectCheck = await pool.query('SELECT id FROM projects WHERE id = $1', [id]);
    if (projectCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const uploadedMedia = [];

    for (const file of req.files) {
      const result = await pool.query(
        `INSERT INTO project_media (
          project_id, media_type, file_name, file_path, file_size,
          configuration, description, uploaded_by
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        RETURNING *`,
        [
          id, media_type || 'image', file.originalname, file.filename,
          file.size, configuration, description, req.user.id
        ]
      );
      uploadedMedia.push(result.rows[0]);
    }

    res.status(201).json({
      message: 'Media uploaded successfully',
      media: uploadedMedia
    });
  } catch (error) {
    console.error('Media upload error:', error);
    res.status(500).json({ error: 'Server error during media upload' });
  }
});

// Update project
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    // Build dynamic update query
    const allowedFields = [
      'project_name', 'developer_name', 'location', 'micro_market',
      'budget_min', 'budget_max', 'configurations', 'description',
      'availability_status', 'inventory_notes', 'client_requirement_tags',
      'google_maps_link',
      'is_visible', 'visibility_settings'
    ];

    // Admin-only fields
    const adminOnlyFields = [
      'attribute_1', 'attribute_2', 'attribute_3', 'attribute_4', 'attribute_5',
      'attribute_6', 'attribute_7', 'attribute_8', 'attribute_9', 'attribute_10',
      'attribute_11', 'attribute_12', 'attribute_13', 'attribute_14', 'attribute_15',
      'attribute_16', 'attribute_17', 'attribute_18', 'attribute_19', 'attribute_20'
    ];

    const updateFields = [];
    const values = [];
    let paramCount = 0;

    // Regular fields - all users can edit
    for (const field of allowedFields) {
      if (updates[field] !== undefined) {
        paramCount++;
        updateFields.push(`${field} = $${paramCount}`);
        values.push(updates[field]);
      }
    }

    // Admin-only fields - only admins can edit
    if (req.user.role === 'admin') {
      for (const field of adminOnlyFields) {
        if (updates[field] !== undefined) {
          paramCount++;
          updateFields.push(`${field} = $${paramCount}`);
          values.push(updates[field]);
        }
      }
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ error: 'No valid fields to update' });
    }

    paramCount++;
    updateFields.push(`updated_at = NOW()`);
    values.push(id);

    const result = await pool.query(
      `UPDATE projects SET ${updateFields.join(', ')} WHERE id = $${paramCount} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    res.json({
      message: 'Project updated successfully',
      project: result.rows[0]
    });
  } catch (error) {
    console.error('Update project error:', error);
    res.status(500).json({ error: 'Server error during update' });
  }
});

// Toggle visibility settings (Admin only)
router.patch('/:id/visibility', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { field, visible, projectVisible } = req.body;

    if (projectVisible !== undefined) {
      // Toggle entire project visibility
      await pool.query(
        'UPDATE projects SET is_visible = $1, updated_at = NOW() WHERE id = $2',
        [projectVisible, id]
      );
    }

    if (field) {
      // Update specific field visibility
      const result = await pool.query(
        `UPDATE projects 
         SET visibility_settings = jsonb_set(
           COALESCE(visibility_settings, '{}'::jsonb),
           $1,
           $2::jsonb
         ),
         updated_at = NOW()
         WHERE id = $3
         RETURNING *`,
        [`{${field}}`, JSON.stringify(visible), id]
      );

      return res.json({
        message: 'Visibility updated',
        project: result.rows[0]
      });
    }

    const result = await pool.query('SELECT * FROM projects WHERE id = $1', [id]);
    res.json({
      message: 'Visibility updated',
      project: result.rows[0]
    });
  } catch (error) {
    console.error('Visibility update error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle media visibility (Admin only)
router.patch('/media/:mediaId/visibility', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { mediaId } = req.params;
    const { visible } = req.body;

    const result = await pool.query(
      'UPDATE project_media SET is_visible = $1 WHERE id = $2 RETURNING *',
      [visible, mediaId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Media not found' });
    }

    res.json({
      message: 'Media visibility updated',
      media: result.rows[0]
    });
  } catch (error) {
    console.error('Media visibility error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete project
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    // Delete associated media files
    const mediaResult = await pool.query(
      'SELECT file_path FROM project_media WHERE project_id = $1',
      [id]
    );

    for (const media of mediaResult.rows) {
      const filePath = path.join(__dirname, '../uploads', media.file_path);
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }
    }

    await pool.query('DELETE FROM projects WHERE id = $1', [id]);

    res.json({ message: 'Project deleted successfully' });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Server error during deletion' });
  }
});

// Download media file
router.get('/media/:mediaId/download', async (req, res) => {
  try {
    const { mediaId } = req.params;

    const result = await pool.query(
      'SELECT file_name, file_path FROM project_media WHERE id = $1',
      [mediaId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'File not found' });
    }

    const { file_name, file_path } = result.rows[0];
    const fullPath = path.join(__dirname, '../uploads', file_path);

    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'File not found on server' });
    }

    res.download(fullPath, file_name);
  } catch (error) {
    console.error('Download error:', error);
    res.status(500).json({ error: 'Server error during download' });
  }
});

// Get similar/recommended projects
router.get('/:id/similar', optionalAuth, async (req, res) => {
  try {
    const { id } = req.params;
    const isAdmin = req.user?.role === 'admin';

    // Get the current project
    const projectResult = await pool.query('SELECT * FROM projects WHERE id = $1', [id]);
    if (projectResult.rows.length === 0) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const project = projectResult.rows[0];

    // Find similar projects based on location, budget range, and configurations
    const similarQuery = `
      SELECT p.*, 
             (
               CASE WHEN location = $2 OR micro_market = $3 THEN 30 ELSE 0 END +
               CASE WHEN configurations && $4 THEN 25 ELSE 0 END +
               CASE WHEN budget_min <= $6 AND budget_max >= $5 THEN 25 ELSE 0 END +
               CASE WHEN developer_name = $7 THEN 10 ELSE 0 END +
               CASE WHEN client_requirement_tags && $8 THEN 10 ELSE 0 END
             ) as similarity_score
      FROM projects p
      WHERE p.id != $1 ${!isAdmin ? 'AND p.is_visible = true' : ''}
      ORDER BY similarity_score DESC, created_at DESC
      LIMIT 5
    `;

    const result = await pool.query(similarQuery, [
      id,
      project.location,
      project.micro_market,
      project.configurations || [],
      project.budget_min || 0,
      project.budget_max || 999999999,
      project.developer_name,
      project.client_requirement_tags || []
    ]);

    res.json({ similar_projects: result.rows });
  } catch (error) {
    console.error('Similar projects error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
